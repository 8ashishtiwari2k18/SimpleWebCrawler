package com.test;

import java.util.List;

public interface WebsiteCrawlerInterface {

	public void crawl(String nextURL); // Give it a URL and it makes an HTTP request for a web page
	public List<String> getLinks(); // Returns a list of all the URLs on the page
}
