package com.test;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebsiteCrawler implements WebsiteCrawlerInterface {

	private static final String USER_AGENT =
            "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1";
	private List<String> links = new LinkedList<String>(); // Just a list of URLs
	private Document htmlDocument; // This is our web page, or in other words, our document
	
	public void crawl(String url)
    {
        try
        {
        	if(StringUtils.isNotEmpty(url) && url.contains("pru")) {
        		Connection connection = Jsoup.connect(url).userAgent(USER_AGENT);
        		Document htmlDocument = connection.get();
        		this.htmlDocument = htmlDocument;

        		System.out.println("Received web page at " + url);

        		Elements linksOnPage = htmlDocument.select("a[href]");
        		System.out.println("Found (" + linksOnPage.size() + ") links");
        		for(Element link : linksOnPage)
        		{
        			this.links.add(link.absUrl("href"));
        		}
        	}
        }
        catch(IOException ioe)
        {
            // We were not successful in our HTTP request
            System.out.println("Error in out HTTP request " + ioe);
        }
    }

	public List<String> getLinks()
	{
		return this.links;
	}
	
	public void search(String url)
    {
		WebVisitor visit = new WebVisitor();
        while(visit.pagesVisited.size() < WebVisitor.MAX_PAGES_TO_SEARCH)
        {
            String currentUrl;
            
            if(visit.pagesToVisit.isEmpty())
            {
                currentUrl = url;
                visit.pagesVisited.add(url);
            }
            else
            {
                currentUrl = visit.nextUrl();
            }
            crawl(currentUrl); 
           
            visit.pagesToVisit.addAll(getLinks());
        }
        System.out.println(String.format("Visited %s web page(s)", visit.pagesVisited.size()));
    }

}
   

