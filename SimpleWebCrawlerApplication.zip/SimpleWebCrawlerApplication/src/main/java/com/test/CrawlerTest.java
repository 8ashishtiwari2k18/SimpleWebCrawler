package com.test;

public class CrawlerTest {

	/**
     * This is our test. It creates a crawler and crawls the web.
     * 
     * @param args
     *            - not used
     */
    public static void main(String[] args)
    {
    	WebsiteCrawler crawler = new WebsiteCrawler();
    	crawler.search("https://www.prudential.co.uk/");
    }
}
