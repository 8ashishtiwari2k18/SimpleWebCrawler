package com.test;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class WebVisitor {
	// Fields
	static final int MAX_PAGES_TO_SEARCH = 100;
	Set<String> pagesVisited = new HashSet<String>();
	List<String> pagesToVisit = new LinkedList<String>();

	/**
	 * Returns the next URL to visit (in the order that they were found). We also do a check to make
	 * sure this method doesn't return a URL that has already been visited.
	 * 
	 * @return
	 */
	String nextUrl()
	{
		String nextUrl;
		do
		{
			nextUrl = this.pagesToVisit.remove(0);
		} while(this.pagesVisited.contains(nextUrl));
		this.pagesVisited.add(nextUrl);
		return nextUrl;
	}
}
